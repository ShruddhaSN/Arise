package com.arise.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.LinearProgressIndicator
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.arise.app.MainActivity
import com.arise.app.data.Store
import com.arise.app.game.Deck
import com.arise.app.game.Game
import com.arise.app.game.fmt
import java.time.LocalDate
import java.time.LocalTime

private data class Snap(
    val level: Int,
    val rank: String,
    val done: Int,
    val total: Int,
    val streak: Int,
    val next: String,
    /** The day after a rest day. */
    val penalty: Boolean,
    val quote: String = "",
    val onTrack: String = "",
    /** Today's wake-up hasn't been tapped yet, and it's past the goal. */
    val wakePending: Boolean = false,
)

private fun snapshot(ctx: Context): Snap {
    val data = Store.load(ctx)
    if (!data.settings.onboarded) return Snap(1, "E", 0, 0, 0, "Open Arise to awaken", false)
    val today = LocalDate.now()
    val now = LocalTime.now()
    val p = Game.progress(data, today)
    val s = Game.status(data, today)
    val deck = Deck.cards(data, today, now)
    val next = Deck.upNext(data, today, now)
    val nextText = when {
        deck.isNotEmpty() -> "NOW · ${deck.first().quest?.title}" + if (deck.size > 1) "  (+${deck.size - 1})" else ""
        next != null -> "${fmt(next.time)} · ${next.quest?.title ?: next.title}"
        else -> {
            val tomorrow = Game.plan(data, today.plusDays(1)).blocks.first()
            "Tomorrow ${fmt(tomorrow.time)} · ${tomorrow.quest?.title ?: tomorrow.title}"
        }
    }
    return Snap(
        level = p.level,
        rank = p.rank,
        done = s.doneCount,
        total = s.total,
        streak = p.streak,
        next = nextText,
        penalty = Game.comebackActive(data, today) && data.day(today).done[Game.comebackQuest.id] == null,
        quote = com.arise.app.game.Quotes.forDay(data.settings, today).second.line,
        onTrack = "${p.consistency}/${p.consistencyOf}",
        wakePending = s.plan.blocks.any { b ->
            b.quest?.kind == com.arise.app.game.Kind.WAKE && !b.time.isAfter(now) && data.day(today).wakeTime == null && now.isBefore(LocalTime.of(14, 0))
        },
    )
}

private val Bg = Color(0xFF0A0F1C)
private val Glow = Color(0xFF4DA3FF)
private val TextMain = Color(0xFFF0EFEC)
private val TextDim = Color(0xFF9AA3B5)
private val Danger = Color(0xFFE66767)
private val Good = Color(0xFF3FBF7F)

class AriseWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val snap = snapshot(context)
        provideContent { WidgetBody(snap) }
    }
}

@Composable
private fun WidgetBody(s: Snap) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(Bg)
            .cornerRadius(16.dp)
            .padding(14.dp)
            .clickable(actionStartActivity<MainActivity>()),
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                "ARISE",
                style = TextStyle(color = ColorProvider(Glow), fontSize = 13.sp, fontWeight = FontWeight.Bold),
            )
            Spacer(GlanceModifier.defaultWeight())
            Text(
                "Lv ${s.level} · ${s.rank}-Rank · 📈${s.onTrack}",
                style = TextStyle(color = ColorProvider(TextDim), fontSize = 12.sp),
            )
        }
        Spacer(GlanceModifier.height(8.dp))
        Text(
            if (s.penalty) "GENTLE DAY · ONE SMALL WIN" else "QUEST",
            style = TextStyle(color = ColorProvider(if (s.penalty) Good else TextDim), fontSize = 10.sp, fontWeight = FontWeight.Bold),
        )
        Text(
            s.next,
            maxLines = 2,
            style = TextStyle(color = ColorProvider(TextMain), fontSize = 15.sp, fontWeight = FontWeight.Medium),
        )
        if (s.wakePending) {
            Spacer(GlanceModifier.height(6.dp))
            WidgetButton("I'M UP", Good, actionRunCallback<WakeCallback>())
        }
        Spacer(GlanceModifier.height(10.dp))
        LinearProgressIndicator(
            progress = if (s.total == 0) 0f else s.done.toFloat() / s.total,
            modifier = GlanceModifier.fillMaxWidth().height(6.dp),
            color = ColorProvider(Glow),
            backgroundColor = ColorProvider(Color(0xFF1C2433)),
        )
        Spacer(GlanceModifier.height(4.dp))
        Text(
            "Core quests ${s.done}/${s.total}",
            style = TextStyle(color = ColorProvider(TextDim), fontSize = 11.sp),
        )
        if (s.quote.isNotBlank()) {
            Spacer(GlanceModifier.height(6.dp))
            Text(s.quote, maxLines = 2, style = TextStyle(color = ColorProvider(TextDim), fontSize = 10.sp))
        }
    }
}

class AriseWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AriseWidget()
}
