# ARISE ⚔️

A Solo Leveling–style life system for Android. A short assessment learns your life (work or college, commute, meals, medicines, routines), then the System gives you daily quests built around it: XP and ranks, a voice-guided run and strength coach, routines, Pomodoro, a screen blocker, growth insights, achievements, pop-ups and widgets. Everything stays on your phone.

## Getting the app onto your phone (nothing to install)

GitHub builds the APK in the cloud, so you don't need Android Studio.

1. **Create a GitHub account** at github.com, if you don't have one.
2. **Create a new repository** (top right **+** → *New repository*):
   - Name: `arise`
   - **Public** (simplest, so your phone can download without logging in) or Private
   - Don't tick "Add a README"
3. **Upload this folder**. On the new repo page, click **"uploading an existing file"**, then drag in **everything inside the `Arise` folder**, including the hidden `.github` folder.
   - On Windows, turn on *View → Show → Hidden items* in File Explorer so you can see `.github`.
   - Click **Commit changes**.
4. **Wait for the build** (about 5 min). Open the **Actions** tab. A green ✓ means it's done.
5. **Download on your phone.** Open this link in your phone's browser:
   `https://github.com/<your-username>/arise/releases/download/latest/Arise.apk`
   You can also go to the repo → **Releases** → **Arise (latest build)** → `Arise.apk`.
6. **Install it.** Tap the downloaded file. Android will ask you to allow installs from your browser. Allow it, then tap **Install**.

### First launch on a Redmi (important)
MIUI aggressively kills background apps. Long-press the Arise icon → **App info**, then set:
- **Autostart** → ON
- **Battery saver** → No restrictions
- **Notifications** → allow all, including lock screen and floating

Then add the widgets: long-press the home screen → **Widgets** → **Arise** (4 kinds).

### Screen blocker
Tools → Screen blocker → turn it on. On Samsung: Settings → Accessibility → Installed apps → Arise → On.
If it's greyed out (Android blocks this for apps installed outside the Play Store): long-press the Arise icon →
**App info** → **⋮** → **Allow restricted settings**, then turn it on.

### Updating
When the code changes, upload the changed files to the repo again. A new APK is built automatically. Install it over the old one and your data stays, because every build is signed with the same key (`app/arise.keystore`).

### Backups
Every Sunday, go to **Player → Save backup file** and save it to Google Drive. That one file holds everything. On a new phone, install Arise and tap **Restore**.

## How the System works

| Thing | Rule |
|---|---|
| Day 1 | The day you finish the assessment. Weeks count from here. Player → Restart wipes everything and starts a new Day 1. |
| Wake-up | Tap I'M UP (app, widget, lock-screen notification or pop-up). The morning re-plans around the real time. |
| Events | Calendar → day → Add an event. Quests move around it; long events excuse training and lessons. |
| Bonus quests | After-meal walks and ⚡ emergency quests earn XP but never count against you. |
| Fill-in days | If you started on paper, those days can be ticked off for XP and streaks. They never cause penalties. Neither does Day 1. |
| Day types | Office, WFH and days off come from your setup (default Mon/Wed/Thu office, Tue/Fri WFH). Tap to switch a day, or pick **Rest / Off** when you're sick or travelling. |
| Training | Run Tue/Fri/Sun · Strength Wed/Sat · Easy walk Mon/Thu |
| Full vs Min | Full = 100% XP. Min = 20% XP and uses 1 of your **2 passes per week**. |
| Cleared day | 70% of quests done (Full or Min). Cleared days build your streak. |
| Penalty | If yesterday wasn't cleared, today has a penalty quest. *Never miss twice.* |
| Progression | Each week, learning time goes up, bedtime moves to 11 PM, water goes to 3 L, and the run and strength plans step up. |
| Ranks | E (Lv 1–4) → D → C → B → A → S (Lv 25+) |

## Project layout
```
app/src/main/java/com/arise/app/
  MainActivity.kt        app shell, tabs, level-up dialog
  data/                  models + JSON storage
  game/Program.kt        schedule, quests, run & strength plans  ← tweak your routine here
  game/Game.kt           XP, levels, streaks, bosses
  game/Knowledge.kt      daily knowledge quiz cards
  game/Profile.kt        the life assessment (branching questions)
  game/Exercises.kt      strength exercise library and session builder
  notify/Reminders.kt    schedule notifications, nudges
  notify/SystemAlert.kt  System pop-ups over other apps / lock screen
  widget/                home-screen widgets
  ui/                    screens and charts
```

## v1.1 changes
Card deck Today screen (Done / Later / Not today), all-day box (water, steps, Korean), partial XP for measurable quests,
wake goals per day type with "I'm up", lesson curriculum with smart shuffle, Korean + sign language tracks, calendar for one-off day types,
sick days, one-time Day 1 change, guided mobility/stretch timers, plank hold timer, protein log, skip patterns,
spotlight tutorial, full-screen level-up, zig-zag level pacing (max ~3.5 weeks per level), rescue-the-day reminder.

## Roadmap (v2)
- Health Connect sync: steps and sleep from Samsung Health or your watch
- Quest editor inside the app
- Cycle-phase notes alongside Flo
